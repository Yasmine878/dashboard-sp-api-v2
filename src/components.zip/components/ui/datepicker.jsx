export function DatePicker() {
    return (
      <input type="date" className="border p-2 rounded" />
    );
  }
  