
import React from 'react';
import '@testing-library/jest-dom';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { vi } from 'vitest';
import Dashboard from './Dashboard';

// 🧪 Mock global fetch
vi.stubGlobal('fetch', vi.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve([
      {
        fournisseur: 'Biotech S.A.',
        date: '07/04/2025',
        heure: '08:15',
        durée: '2m35s',
        commandes: 324,
      },
    ]),
  })
));

// 🧪 Mock Chart.js pour éviter les erreurs jsdom
vi.mock('chart.js/auto', () => ({
  default: class {},
}));

describe('Dashboard - Tests d’intégration', () => {
  it('charge et affiche les données API', async () => {
    render(<Dashboard />);
    
    await waitFor(() => {
      // ✅ Utilisation de getByRole pour éviter les doublons
      const cell = screen.getByRole('cell', { name: 'Biotech S.A.' });
      expect(cell).toBeInTheDocument();
    });
  });
});



it('rafraîchit les données quand on clique sur le bouton', async () => {
    render(<Dashboard />);
    const button = screen.getByRole('button', { name: /rafraîchir/i });
    await userEvent.click(button);
    await waitFor(() => {
      expect(screen.getByText('Biotech S.A.')).toBeInTheDocument();
    });
  });















