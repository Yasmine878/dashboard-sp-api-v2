
import React from 'react';
export default function AlertBox({ message }) {
    return <div className="alert-box">{message}</div>;
  }
  